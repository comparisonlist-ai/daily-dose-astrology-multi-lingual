Daily Rashifal App - Android APK build

App name: Daily Rashifal App
Package: com.comparisonlist.dailyrashifal
Version: 1.0.0
Web URL:
https://comparisonlist-ai.github.io/daily-dose-astrology-multi-lingual/

Build from GitHub Actions:
1. Put this project in a GitHub repository.
2. Open Actions > Build Daily Rashifal App APK.
3. Select Run workflow.
4. After it finishes, download the DailyRashifalApp-release artifact.

Note: the release build produced by this workflow is unsigned unless signing is added.
For an Uptodown-ready signed release, configure a persistent Android keystore before publishing, so future updates can use the same signing key.
